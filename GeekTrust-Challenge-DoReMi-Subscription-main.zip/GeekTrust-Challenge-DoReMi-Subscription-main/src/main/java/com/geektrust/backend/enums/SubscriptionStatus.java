package com.geektrust.backend.enums;

public enum SubscriptionStatus {
    NOT_STARTED,STARTED, ADDED
}
