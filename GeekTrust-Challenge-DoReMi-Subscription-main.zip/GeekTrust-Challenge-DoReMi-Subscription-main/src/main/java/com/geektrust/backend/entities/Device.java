package com.geektrust.backend.entities;

public abstract class Device {
    protected Integer price;
    public Integer getPrice() {
        return price;
    }
}
