package com.geektrust.backend.enums;

public enum DeviceType {
    TEN_DEVICE,FOUR_DEVICE
}
