package com.geektrust.backend.enums;

public enum TopUpStatus {
    EMPTY,ADDED
}
