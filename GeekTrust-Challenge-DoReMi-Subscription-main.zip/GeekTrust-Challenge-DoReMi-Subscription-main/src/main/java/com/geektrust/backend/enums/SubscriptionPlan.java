package com.geektrust.backend.enums;

public enum SubscriptionPlan {
    FREE,PERSONAL,PREMIUM
}
