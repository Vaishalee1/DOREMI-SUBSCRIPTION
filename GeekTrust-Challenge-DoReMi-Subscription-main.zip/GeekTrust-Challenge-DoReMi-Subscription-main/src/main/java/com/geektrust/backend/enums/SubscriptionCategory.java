package com.geektrust.backend.enums;

public enum SubscriptionCategory {
    MUSIC,VIDEO,PODCAST
}
